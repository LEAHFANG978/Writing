"""本地形式校验与主文档汇编；不替代人工编辑或事实核查。"""
from pathlib import Path
from collections import Counter
import csv
import re

ROOT = Path(__file__).resolve().parent
PARTS = [
    '01-世界与人物.md', '02-术语知识库.md', '03-品牌与业务素材.md',
    '04-组织生态.md', '05A-十篇重点大纲.md', '05B-品牌选题大纲.md',
    '06-技法与规范.md', '07-目录与连续性.md',
]
texts = [(ROOT / '分卷' / name).read_text(encoding='utf-8') for name in PARTS]
terms = re.findall(r'^\|(\d{3})／[ABCD]\|', texts[1], re.M)
assert len(terms) >= 150 and len(terms) == len(set(terms))
outlines = texts[4] + '\n' + texts[5]
topics = re.findall(r'^## (\d{2})《(.*?)》', outlines, re.M)
assert len(topics) == 44 and len(dict(topics)) == 44
assert [int(n) for n, _ in topics] == list(range(1, 45))
lengths = []
for section in re.split(r'\n## (?=\d)', texts[4])[1:]:
    title = section.splitlines()[0]
    body = section.split('### 详细大纲\n', 1)[1]
    count = len(re.sub(r'\s', '', body))
    assert 800 <= count <= 1200, (title, count)
    lengths.append((title, count))
with (ROOT / '作品目录.csv').open(encoding='utf-8', newline='') as file:
    rows = list(csv.DictReader(file))
assert len(rows) == 44
assert [(row['id'], row['title']) for row in rows] == topics
for row in rows:
    values = list(map(int, row['scores'].split('-')))
    assert len(values) == 10 and all(1 <= x <= 5 for x in values)
    assert sum(values) == int(row['total']) >= 40
brands = Counter(row['brand'] for row in rows if row['track'] == '虚构行业案例')
assert len(brands) == 12 and all(value >= 3 for value in brands.values())

intro = '''# 甲虫文学｜快消职场荒诞小说创作圣经

版本：V0.1 · 建档日期：2026-10-16

这是一份已经展开内容的长期创作主文档。现有156条表达、12个品牌素材库、44篇故事大纲，其中前10篇各800—1200字；本次没有将大纲冒充2000—3000字小说成稿。编辑自评与未来创作计划均非发布记录。

人物、雇主、业务事件及制度均为虚构。真实品牌用于产品背景和架空行业案例，不表示其发生过文中事件。品牌基础信息依据背景知识整理，本次官方网页请求被代理403拒绝，未完成现场核验；具体事实状态与待核入口见第三卷。薪资40万元、职级规则、工具及绩效流程均不能引用为宝洁政策。

阅读顺序：第一卷世界与人物→第二卷术语→第三卷品牌→第四卷组织→第五卷选题与大纲→第六卷技法与质量→第七卷目录与连续性。

维护源为“分卷”目录与作品目录.csv。本文件由校验与汇编.py重建。单独复制案例篇时须保留其随文虚构标识。所有新选题先确定讽刺命题，再选择产品与情节。

---

'''
# 汇编后所有分卷中的“../作品目录.csv”链接改为主文档同目录链接。
master = intro + '\n\n---\n\n'.join(texts)
master = master.replace('(../作品目录.csv)', '(作品目录.csv)')
target = ROOT / '甲虫文学｜快消职场荒诞小说创作圣经.md'
target.write_text(master.rstrip() + '\n', encoding='utf-8')
print(f'术语：{len(terms)}；选题：{len(topics)}；品牌：{len(brands)}，每品牌至少3题。')
print('重点大纲去空白字符数：')
for title, count in lengths:
    print(f'  {title}: {count}')
print(f'十项评分总和全部一致，全部不低于40；成稿与发布记录均为0。')
print(f'已汇编：{target.name}（{len(master):,}字符）。')
