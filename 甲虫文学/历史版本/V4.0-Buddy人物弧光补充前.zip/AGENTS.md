# 《甲虫文学》长期创作规则

适用本仓库全部后续创作、人物设定、大纲、主文档与导出。用户的“宝劫集团”世界观、V0.3职级正式修正及V4.0精英文化补充为长期有效设定；除非用户明确再次修改，不得退回旧公司名与旧人物名。

## 固定世界观

- 中文正式名：宝劫集团；英文：Pain & Growth；缩写：P&G。这是虚构跨国快消企业，经营美妆个护、家庭清洁、婴儿护理等业务。不可将其与真实宝洁或真实Procter & Gamble混同。
- Slogan：Touching Lives, Improving KPIs.／亲近生活，改善指标。只在合适场景自然出现，不每篇重复，不解释公司名称的谐音。
- 公司专业且严肃，强调Leadership、Business Results；文化包括Ownership、Growth Mindset、Leadership、Consumer is Boss、One Team、Speak Up、Work-life Balance、Productivity、Winning Culture。理念可有合理作用；讽刺通过具体事件、行为、权力与反转产生。

## 人物命名与身份

- 公司内部员工、经理和管理层全部使用固定英文名；同事对话不得用中文姓名或张经理、王总、小刘等称呼。英文岗位与Band职级保留。
- 主角固定为Gregor（格里高尔）；叙述可称Gregor、格里高尔或甲虫，内部称呼使用Gregor。不得新增一个同名格里高尔角色。
- 必须先读`甲虫文学/人物档案.json`与`甲虫文学/分卷/01-世界与人物.md`：David＝Band 4 Marketing VP；Michael＝Band 3 Marketing Director及Gregor直属Line Manager；Jessica＝HRBP；Kevin＝Finance Manager；Emily＝CMK Manager；Ryan＝CBD Manager；Alex＝IT Manager；Sophia＝R&D Manager；Chris＝Marketing好搭子；Olivia＝Band 2 Senior Brand Manager；Daniel＝Band 5 Regional VP。
- Chris与Ryan是两个人；Chris不得再写成销售运营员工。Chris有真实能力、幽默与友谊，在T29的绩效与岗位竞争后离开。David与Daniel分属本地Marketing和Regional层级，不可互换。Michael固定为Band 3 Director，向David汇报；David向Daniel汇报。
- 所有已登记人物的Band、Title、直属汇报与年资以人物档案.json为准，不得临时推算或改动；新增角色先登记。外部角色不套集团Band；保持部门、关系与性别连续。新增人物先登记，再写正文；外部Agency等职业角色也沿用英文名。

## 正史与品牌

- 正史从T0入职起算，Gregor T0即Band 1 Manager，T12（约一年）晋升Band 2 Manager，仍无直接下属；Chris与Gregor同批T0入职，T12升Band 2，T29离职。离职后公司内出现须交代回忆或合理来访。
- 可以为宝劫集团设计虚构品牌，须先登记。真实商标可作产品背景或明确标识的虚构行业案例；不得暗示真实品牌曾发生所写事件，不得把真实品牌列为宝劫集团实际资产。
- 薪酬、绩效、IT工具均为本系列虚构规则；PVP不得误写为真实企业的绩效淘汰制度。真实事实未核实时保留待核标识。

## 创作及文档维护

- 单篇正文2000—3000字，按去空白字符数计，标题、虚构说明、编辑卡不计。第三人称，主要跟随Gregor；至少三个完整场景、清晰目标、三次递进冲突、有自身利益的配角及不讲道理的文学结尾。
- 先确定一句平实讽刺命题，再选产品和情节。英文术语主要用于对话、邮件、会议与材料；普通叙述自然中文，不每句话塞术语。
- 人物不能只有好坏标签，也不能用“Gregor终于明白”收束所有故事。保留甲虫的善意、敏感、虚荣与有限选择。
- 未经用户确认不得覆盖、替换或批量改名已完成的小说正文。先列入`甲虫文学/设定更新记录.md`，必要时另建修订建议稿；已有完成正文优先保护。本次授权可更新设定文档及未成稿大纲。
- 修改分卷、人物档案和作品目录后，运行`python 甲虫文学/校验与汇编.py`；同步主文档和新版本导出。旧版本仅在历史归档及迁移说明中保留，不作为当前创作依据。
- 新稿保存于`甲虫文学/小说正文/`，追加编辑卡、实际字数、时间线和状态；初稿不等于用户定稿，成稿不等于已发布。不得伪造发布记录。

## V0.3正式职级修正：覆盖此前冲突规则

- Band 1：校招入职即Manager，不是普通专员。Band 2：通常约一年晋升的Manager，不是Director；Band 3：Director，担任Band 1、Band 2的Line Manager。
- Title、Band、直属下属人数、预算审批权分别登记，不能相互替代。Gregor从入职就管理项目、Agency、Timeline、Stakeholders和Expectations，却没有下属、团队预算最终审批权或独立品牌策略决定权。
- Marketing固定线：Gregor／Chris／Olivia／Leo → Michael（Band 3 Director）→ David（Band 4 Marketing VP）→ Daniel（Band 5 Regional VP）→ Global President（Band 6，未出场职务）。Band 4—6是本系列已登记设定，不外推真实企业。
- Michael保留关键Decision和授权内预算控制；Scope扩大不等于Gregor获得同比资源。约一年升Band 2不保证很快升Band 3。Olivia为资深Band 2，不能因Title中的Senior自动升为Director。
- 其他内部职能Manager均为Band 2，直属各职能Band 3 Director；Jessica支持Marketing但人事上向HR Director汇报。写前查年资基准和事件月，Leo T27前未入职。
- 06《献给Director的生日》的对象为Michael，不能继续让David以Director身份过生日。01当前稿在职级修订稿文件；历史原初稿只用于追溯，不作为新创作依据。

## V4.0精英文化补充：不得覆盖旧作品

- 本次是补充，不重建公司、不改既有Band。T96为入职八年的系列当下，Gregor约八年跨国快消经验；T0入职、T12约一年晋升、Chris T29离职均保留。旧篇01仍在T12，不得把一句刚满一年直接改为八年，也不因新版本重新导出覆盖其Word。
- Gregor为世界排名Top 20的美国大学硕士，IELTS裸考7.5；校名、榜单与年份未定，不擅自补真实名次。他分析、执行、协调与解决问题能力强，认真敏感、善良且有虚荣；会比较学历、追求晋升及推动荒诞流程，不是唯一优秀或清醒的人。
- 十二位核心人物学校严格从人物档案.json读取：Michael北大，David清华本科加美国MBA，Jessica复旦本科加海外硕士，Kevin上海交大金融相关，Emily北大心理学相关，Ryan浙大，Alex华中科大计算机相关，Sophia清华理工硕士，Chris南大，Olivia广外，Daniel海外知名商学院MBA。未指定专业、学位、榜单、学校的部分不得擅填。
- 公司人才多元，涵盖清北、其他985／211／双一流、美国Top 20、英国G5、海外商学院及广外等特色高校。全部属于虚构员工画像，不作为真实宝洁学历分布、录用门槛或晋升年龄规律。学校不决定能力、性格或道德，不贬低广外及非985群体。
- 可以讽刺人物的学历比较与排名敏感，叙述者不得认可学校等级链；先呈现真正的专业能力，再通过任务、激励与权限表现能力如何被转移。理念和专业方法可以确有帮助，不能以精英无能或集体虚伪作答案。
- 学历只在改变情节时出现，不机械报学校，不写出总命题解释寓意。Olivia的商业能力不只是政治技巧；Chris的友情、幽默和能力不只服务于离职；Michael和David保留关心员工与受上级评价制约的多面性。
- Aaron、Claire分别填入既有Finance Director、CMK Director职务，Band 3且向Daniel汇报；Kevin／Emily直属其相应职能负责人。Nina、Ben是美国硕士同学，非公司同届，均为外部角色。Chris在T96不在职，不因八周年采访复活原岗位。
- 既有小说正文、Word及编辑卡维持原样；版本4.0是世界观版本，不等于小说稿件版本。冲突与兼容性只记录在设定更新记录.md。只有用户另行明确要求修稿时才编辑正文；导出脚本默认不覆盖已有小说Word。
- 新选题45—54见第五卷C，与旧篇去重后再写；正文仍2000—3000字。新题不是新成稿，目录当前总数为54，完成稿数量不随新增题目增加。
