"""本地形式校验与主文档汇编；不替代人工编辑或事实核查。"""
from pathlib import Path
from collections import Counter
import csv
import json
import re

ROOT = Path(__file__).resolve().parent
PARTS = [
    '01-世界与人物.md', '02-术语知识库.md', '03-品牌与业务素材.md',
    '04-组织生态.md', '05A-十篇重点大纲.md', '05B-品牌选题大纲.md',
    '06-技法与规范.md', '07-目录与连续性.md',
]
texts = [(ROOT / '分卷' / name).read_text(encoding='utf-8') for name in PARTS]
terms = re.findall(r'^\|(\d{3})／[ABCD]\|', texts[1], re.M)
assert len(terms) >= 150 and len(terms) == len(set(terms))
outlines = texts[4] + '\n' + texts[5]
topics = re.findall(r'^## (\d{2})《(.*?)》', outlines, re.M)
assert len(topics) == 44 and len(dict(topics)) == 44
assert [int(n) for n, _ in topics] == list(range(1, 45))
lengths = []
for section in re.split(r'\n## (?=\d)', texts[4])[1:]:
    title = section.splitlines()[0]
    body = section.split('### 详细大纲\n', 1)[1]
    count = len(re.sub(r'\s', '', body))
    assert 800 <= count <= 1200, (title, count)
    lengths.append((title, count))
with (ROOT / '作品目录.csv').open(encoding='utf-8', newline='') as file:
    rows = list(csv.DictReader(file))
assert len(rows) == 44
assert [(row['id'], row['title']) for row in rows] == topics
for row in rows:
    values = list(map(int, row['scores'].split('-')))
    assert len(values) == 10 and all(1 <= x <= 5 for x in values)
    assert sum(values) == int(row['total']) >= 40
brands = Counter(row['brand'] for row in rows if row['track'] == '虚构行业案例')
assert len(brands) == 12 and all(value >= 3 for value in brands.values())

profiles = json.loads((ROOT / '人物档案.json').read_text(encoding='utf-8'))
assert profiles['company'] == {
    'zh': '宝劫集团', 'en': 'Pain & Growth', 'abbreviation': 'P&G',
    'fictional': True, 'slogan_en': 'Touching Lives, Improving KPIs.',
    'slogan_zh': '亲近生活，改善指标。',
}
names = [person['name'] for person in profiles['characters']]
assert len(names) == len(set(names))
assert set(['Gregor', 'David', 'Michael', 'Jessica', 'Kevin', 'Emily',
            'Ryan', 'Alex', 'Sophia', 'Chris', 'Olivia', 'Daniel']) <= set(names)
for name in names:
    assert re.fullmatch(r'[A-Z][a-z]+', name) and f'|{name}|' in texts[0]
people = {person['name']: person for person in profiles['characters']}
positions = profiles['positions']
assert profiles['version'] == '0.3'
assert (people['Michael']['band'], people['Michael']['title'],
        people['Michael']['reports_to_name']) == ('Band 3', 'Marketing Director', 'David')
assert (people['David']['band'], people['David']['title'],
        people['David']['reports_to_name']) == ('Band 4', 'Marketing VP', 'Daniel')
assert (people['Daniel']['band'], people['Daniel']['title']) == ('Band 5', 'Regional VP')
assert people['Olivia']['band'] == 'Band 2'
for name in ['Gregor', 'Chris']:
    assert people[name]['joined_at'] == 'T0'
    assert people[name]['career_events'][:2] == [
        {'month': 0, 'band': 'Band 1', 'title': 'Brand Manager'},
        {'month': 12, 'band': 'Band 2', 'title': 'Brand Manager'},
    ]
for person in people.values():
    if person['employment_type'] == '宝劫集团内部':
        assert person['band'] and person['title']
        position = person['reports_to_position']
        assert position in positions
        assert person['reports_to_name'] == positions[position]['incumbent']
        assert person['tenure_reference_month'] is not None
        assert person['tenure_years_at_reference'] >= 0
    else:
        assert person['band'] == '不适用（外部）'
for position in positions:
    seen = set()
    while position is not None:
        assert position not in seen, ('汇报线循环', position)
        seen.add(position)
        position = positions[position]['reports_to']
active = '\n'.join(texts) + (ROOT / '作品目录.csv').read_text(encoding='utf-8')
assert 'T24' not in active
assert not any(phrase in active for phrase in ['David为Marketing Director',
              'Michael没有自动获得Director', 'Band 1，品牌助理', 'Band 1为项目执行岗'])
assert next(row for row in rows if row['id'] == '01')['time'] == 'T12'
section06 = next(section for section in re.split(r'\n## (?=\d)', texts[4])[1:]
                 if section.startswith('06'))
assert 'Michael' in section06 and 'David生日' not in section06
legacy_names = ['恒澜', '周禾', '陈岚', '叶祺', '许曼', '邵言', '罗宁',
                '孟梨', '沈卓', '丁棠', '温夏', '李默', '苏敏', '顾衡', '郑姨']
assert not any(name in active for name in legacy_names)
fiction = sorted((ROOT / '小说正文').glob('*.md'))
for path in fiction:
    text = path.read_text(encoding='utf-8')
    assert not any(name in text for name in legacy_names)
    assert not re.search(r'[张王李刘陈赵]经理|[张王李刘陈赵]总|[张王李刘陈赵]主管|小[刘王张李]', text)
    assert '*人物、公司及事件均属虚构。*\n' in text
    body = text.split('*人物、公司及事件均属虚构。*\n', 1)[1]
    count = len(re.sub(r'\s', '', body))
    assert 2000 <= count <= 3000, (path.name, count)
    card = json.loads(path.with_suffix('.json').read_text(encoding='utf-8'))
    assert card['world_version'] == '0.3'
    assert count == card['body_characters']
    assert sum(card['scores']) == card['total_score']
    assert all(name in names for name in card['named_characters'])
    assert card['published'] is False and card['user_approved'] is False
    if card['id'] == '01':
        assert card['time'] == 'T12' and '待了两年' not in body
        assert '刚满一年' in body and 'Band 3 Director Michael' in body
        assert 'Marketing VP David' in body
assert len(fiction) == sum('稿已写' in row['status'] for row in rows)

intro = '''# 甲虫文学｜快消职场荒诞小说创作圣经

版本：V0.3 · 建档日期：2026-10-16 · 本次更新：正式职级、汇报关系与任职年限

这是一份已经展开内容的长期创作主文档。现有156条表达、12个品牌素材库、44篇故事大纲，其中前10篇各800—1200字；完整初稿数量见第七卷与作品目录，不将大纲或初稿计作用户定稿或发布记录。

当前虚构雇主统一为宝劫集团（Pain & Growth，P&G）。Slogan为Touching Lives, Improving KPIs.／亲近生活，改善指标。公司内部以英文名互称，角色身份依第一卷与人物档案.json保持连续。长期规则另存仓库AGENTS.md；版本迁移及旧稿保护记录见设定更新记录.md。旧版归档不再作为新创作依据。

正式职级：Band 1校招入职即Manager，Gregor与Chris在T0入职、T12约一年升Band 2；Band 3 Director担任其Line Manager。Michael为Band 3 Marketing Director，向David（Band 4 Marketing VP）汇报，David向Daniel（Band 5 Regional VP）汇报。Band与Title不等同；其他角色的职级、岗位、年资和汇报线已登记。责任扩大不自动增加下属或审批权。01原稿完整归档，当前正文为另存的职级修订稿。

人物、雇主、业务事件及制度均为虚构。真实品牌用于产品背景和架空行业案例，不表示其发生过文中事件。品牌基础信息依据背景知识整理，本次官方网页请求被代理403拒绝，未完成现场核验；具体事实状态与待核入口见第三卷。薪资40万元、职级规则、工具及绩效流程均不能引用为宝洁政策。

阅读顺序：第一卷世界与人物→第二卷术语→第三卷品牌→第四卷组织→第五卷选题与大纲→第六卷技法与质量→第七卷目录与连续性。

维护源为“分卷”目录与作品目录.csv。本文件由校验与汇编.py重建。单独复制案例篇时须保留其随文虚构标识。所有新选题先确定讽刺命题，再选择产品与情节。

---

'''
# 汇编后所有分卷中的“../作品目录.csv”链接改为主文档同目录链接。
master = intro + '\n\n---\n\n'.join(texts)
master = master.replace('(../作品目录.csv)', '(作品目录.csv)')
target = ROOT / '甲虫文学｜快消职场荒诞小说创作圣经.md'
target.write_text(master.rstrip() + '\n', encoding='utf-8')
print(f'术语：{len(terms)}；选题：{len(topics)}；品牌：{len(brands)}，每品牌至少3题。')
print('重点大纲去空白字符数：')
for title, count in lengths:
    print(f'  {title}: {count}')
print(f'十项评分总和全部一致，全部不低于40；完整初稿{len(fiction)}篇，用户定稿与发布记录均为0。')
print('公司名、核心角色、T12晋升、职级与汇报线、年资及正文命名／字数校验通过。')
print(f'已汇编：{target.name}（{len(master):,}字符）。')
