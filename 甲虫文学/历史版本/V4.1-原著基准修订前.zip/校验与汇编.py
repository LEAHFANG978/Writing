"""本地形式校验与主文档汇编；不替代人工编辑或事实核查。"""
from pathlib import Path
from collections import Counter
import csv
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
PARTS = [
    '01-世界与人物.md', '02-术语知识库.md', '03-品牌与业务素材.md',
    '04-组织生态.md', '05A-十篇重点大纲.md', '05B-品牌选题大纲.md',
    '05C-精英文化十题.md', '05D-Buddy人物线十题.md',
    '06-技法与规范.md', '07-目录与连续性.md',
]
texts = [(ROOT / '分卷' / name).read_text(encoding='utf-8') for name in PARTS]
terms = re.findall(r'^\|(\d{3})／[ABCD]\|', texts[1], re.M)
assert len(terms) >= 150 and len(terms) == len(set(terms))
outlines = '\n'.join(texts[4:8])
topics = re.findall(r'^## (\d{2})《(.*?)》', outlines, re.M)
assert len(topics) == 64 and len(dict(topics)) == 64
assert [int(n) for n, _ in topics] == list(range(1, 65))
lengths = []
for section in re.split(r'\n## (?=\d)', texts[4])[1:]:
    title = section.splitlines()[0]
    body = section.split('### 详细大纲\n', 1)[1]
    count = len(re.sub(r'\s', '', body))
    assert 800 <= count <= 1200, (title, count)
    lengths.append((title, count))
with (ROOT / '作品目录.csv').open(encoding='utf-8', newline='') as file:
    rows = list(csv.DictReader(file))
assert len(rows) == 64
assert [(row['id'], row['title']) for row in rows] == topics
for row in rows:
    values = list(map(int, row['scores'].split('-')))
    assert len(values) == 10 and all(1 <= x <= 5 for x in values)
    assert sum(values) == int(row['total']) >= 40
brands = Counter(row['brand'] for row in rows if row['track'] == '虚构行业案例')
assert len(brands) == 12 and all(value >= 3 for value in brands.values())

profiles = json.loads((ROOT / '人物档案.json').read_text(encoding='utf-8'))
assert profiles['company'] == {
    'zh': '宝劫集团', 'en': 'Pain & Growth', 'abbreviation': 'P&G',
    'fictional': True, 'slogan_en': 'Touching Lives, Improving KPIs.',
    'slogan_zh': '亲近生活，改善指标。',
}
names = [person['name'] for person in profiles['characters']]
assert len(names) == len(set(names))
assert set(['Gregor', 'David', 'Michael', 'Jessica', 'Kevin', 'Emily',
            'Ryan', 'Alex', 'Sophia', 'Chris', 'Olivia', 'Daniel']) <= set(names)
for name in names:
    assert re.fullmatch(r'[A-Z][a-z]+', name) and f'|{name}|' in texts[0]
people = {person['name']: person for person in profiles['characters']}
positions = profiles['positions']
assert profiles['version'] == '4.1'
assert profiles['series_present']['month'] == 96
assert profiles['series_present']['gregor_experience_years'] == 8
assert people['Gregor']['current_at_T96']['band'] == 'Band 2'
assert people['Gregor']['language_background']['score'] == 7.5
expected_schools = {
    'Gregor': 'Top 20', 'Michael': '北京大学', 'David': '清华大学',
    'Jessica': '复旦大学', 'Kevin': '上海交通大学', 'Emily': '北京大学',
    'Ryan': '浙江大学', 'Alex': '华中科技大学', 'Sophia': '清华大学',
    'Chris': '南京大学', 'Olivia': '广东外语外贸大学', 'Daniel': '商学院MBA',
}
for name, school in expected_schools.items():
    assert school in people[name]['education']['summary']
    assert people[name]['education']['fictional'] is True
for person in people.values():
    assert 'education' in person and person['education']['fictional'] is True
    assert person['ability_profile']['caused_by_school'] is False
assert profiles['education_policy']['school_does_not_determine_ability'] is True
assert people['Kevin']['reports_to_name'] == 'Aaron'
assert people['Emily']['reports_to_name'] == 'Claire'
for name in ['Michael', 'Aaron', 'Claire']:
    assert people[name]['band'] == 'Band 3'
    assert '北京大学' in people[name]['education']['summary']
new_rows = [row for row in rows if 45 <= int(row['id']) <= 54]
assert len(new_rows) == 10
assert len({row['mechanism'] for row in new_rows}) == 10
assert all(row['status'] == '已建大纲／未成稿' for row in new_rows)
buddy_rows = [row for row in rows if int(row['id']) >= 55]
assert len(buddy_rows) == 10
assert len({row['mechanism'] for row in buddy_rows}) == 10
assert profiles['buddy_arc']['shared_work_months'] == [4, 5, 6, 7]
assert profiles['buddy_arc']['formal_first_buddy_recipient'] == 'Leo'
assert profiles['buddy_arc']['first_formal_buddy_month'] == 27
assert profiles['buddy_arc']['active_help_begins_month'] == 25
assert people['Thomas']['coach_assignment']['is_gregor_line_manager'] is False
assert people['Thomas']['coach_assignment']['quote'] == 'Life is your priority.'
assert people['Gregor']['reports_to_name'] == 'Michael'
for name, month, manager in [('Emma', 90, 'Michael'), ('Lucas', 89, None),
                             ('Grace', 84, 'Claire'), ('Ethan', 95, 'Aaron')]:
    assert people[name]['joined_at'] == f'T{month}'
    assert people[name]['reports_to_name'] == manager
    assert people[name]['career_events'][0]['band'] == 'Band 1'
    assert people[name]['has_direct_reports'] is False
assert people['Grace']['current_at_T96']['band'] == 'Band 2'
assert (people['Michael']['band'], people['Michael']['title'],
        people['Michael']['reports_to_name']) == ('Band 3', 'Marketing Director', 'David')
assert (people['David']['band'], people['David']['title'],
        people['David']['reports_to_name']) == ('Band 4', 'Marketing VP', 'Daniel')
assert (people['Daniel']['band'], people['Daniel']['title']) == ('Band 5', 'Regional VP')
assert people['Olivia']['band'] == 'Band 2'
for name in ['Gregor', 'Chris']:
    assert people[name]['joined_at'] == 'T0'
    assert people[name]['career_events'][:2] == [
        {'month': 0, 'band': 'Band 1', 'title': 'Brand Manager'},
        {'month': 12, 'band': 'Band 2', 'title': 'Brand Manager'},
    ]
for person in people.values():
    if person['employment_type'] == '宝劫集团内部':
        assert person['band'] and person['title']
        position = person['reports_to_position']
        assert position in positions
        assert person['reports_to_name'] == positions[position]['incumbent']
        assert person['tenure_reference_month'] is not None
        assert person['tenure_years_at_reference'] >= 0
    else:
        assert person['band'] == '不适用（外部）'
for position in positions:
    seen = set()
    while position is not None:
        assert position not in seen, ('汇报线循环', position)
        seen.add(position)
        position = positions[position]['reports_to']
active = '\n'.join(texts) + (ROOT / '作品目录.csv').read_text(encoding='utf-8')
assert 'T24' not in active
assert not any(phrase in active for phrase in ['David为Marketing Director',
              'Michael没有自动获得Director', 'Band 1，品牌助理', 'Band 1为项目执行岗'])
assert next(row for row in rows if row['id'] == '01')['time'] == 'T12'
section06 = next(section for section in re.split(r'\n## (?=\d)', texts[4])[1:]
                 if section.startswith('06'))
assert 'Michael' in section06 and 'David生日' not in section06
legacy_names = ['恒澜', '周禾', '陈岚', '叶祺', '许曼', '邵言', '罗宁',
                '孟梨', '沈卓', '丁棠', '温夏', '李默', '苏敏', '顾衡', '郑姨']
assert not any(name in active for name in legacy_names)
fiction = sorted((ROOT / '小说正文').glob('*.md'))
for path in fiction:
    text = path.read_text(encoding='utf-8')
    assert not any(name in text for name in legacy_names)
    assert not re.search(r'[张王李刘陈赵]经理|[张王李刘陈赵]总|[张王李刘陈赵]主管|小[刘王张李]', text)
    assert '*人物、公司及事件均属虚构。*\n' in text
    body = text.split('*人物、公司及事件均属虚构。*\n', 1)[1]
    count = len(re.sub(r'\s', '', body))
    assert 2000 <= count <= 3000, (path.name, count)
    card = json.loads(path.with_suffix('.json').read_text(encoding='utf-8'))
    # 已有作品保留写作时版本，不因人物档案升级而改写其编辑卡。
    assert card['world_version'] in ['0.3', '4.0', '4.1']
    assert count == card['body_characters']
    assert sum(card['scores']) == card['total_score']
    assert all(name in names for name in card['named_characters'])
    assert card['published'] is False and card['user_approved'] is False
    if card['id'] == '01':
        assert card['time'] == 'T12' and '待了两年' not in body
        assert '刚满一年' in body and 'Band 3 Director Michael' in body
        assert 'Marketing VP David' in body
    if card['id'] == '58':
        assert card['time'] == 'T95—T96'
        assert {'Gregor', 'Emma', 'Lucas', 'Grace', 'Michael', 'Thomas', 'Ethan'} <= set(card['named_characters'])
        assert body.count('If you need help, you can talk to Gregor.') == 1
        assert body.count('Life is your priority.') == 1
        assert card['body_characters'] == 2729
assert len(fiction) == sum('稿已写' in row['status'] for row in rows)
frozen = json.loads((ROOT / '历史版本' / 'V4.0-既有正文保护摘要.json').read_text(encoding='utf-8'))
for item in frozen:
    assert hashlib.sha256((ROOT / item['path']).read_bytes()).hexdigest() == item['sha256'], item['path']
buddy_frozen = json.loads((ROOT / '历史版本' / 'V4.1-升级前正文保护摘要.json').read_text(encoding='utf-8'))
for item in buddy_frozen:
    assert hashlib.sha256((ROOT / item['path']).read_bytes()).hexdigest() == item['sha256'], item['path']

intro = '''# 甲虫文学｜快消职场荒诞小说创作圣经

版本：V4.1 · 建档日期：2026-10-16 · 本次补充：Gregor成为别人的Buddy

这是一份已经展开内容的长期创作主文档。现有156条表达、12个品牌素材库、64篇故事大纲，其中前10篇各800—1200字；完整正文数量见第七卷与作品目录，不将大纲或初稿计作用户定稿或发布记录。第五卷C为45—54精英文化题，第五卷D为55—64 Buddy人物线，不替换旧题。

当前虚构雇主统一为宝劫集团（Pain & Growth，P&G）。Slogan为Touching Lives, Improving KPIs.／亲近生活，改善指标。公司内部以英文名互称，角色身份依第一卷与人物档案.json保持连续。长期规则另存仓库AGENTS.md；版本迁移及旧稿保护记录见设定更新记录.md。旧版归档不再作为新创作依据。

正式职级：Band 1校招入职即Manager，Gregor与Chris在T0入职、T12约一年升Band 2；Band 3 Director担任其Line Manager。Michael为Band 3 Marketing Director，向David（Band 4 Marketing VP）汇报，David向Daniel（Band 5 Regional VP）汇报。Band与Title不等同；其他角色的职级、岗位、年资和汇报线已登记。责任扩大不自动增加下属或审批权。01原稿完整归档，当前正文为另存的职级修订稿。

V4.0员工画像继续生效：T96为入职八年的系列当下，早期篇保留原时间；Gregor为世界排名Top 20的美国大学硕士，IELTS裸考7.5，具有约八年跨国快消经验。学校不决定价值、性格与道德；相关履历和晋升年龄均为虚构，不能当作真实宝洁人员统计。

V4.1补充一条贯穿八年的Buddy弧光：T4—T7仅四个月的Thomas项目Coaching，T25起主动帮助新人，T27首次正式成为Leo的Buddy，后续逐渐学习Boundary。Gregor有专业成绩但不最拔尖，会自疑、羡慕、误判并影响自身交付；帮助他人不抵扣错误，也不替代收入、职业与业务追求。People Caring制度和具体的人可以共同有效，不将HR与其他Leader写成反派。新增Emma、Lucas、Grace、Ethan，均有独立能力与正式汇报线。58《没有写进Performance Review的事》已写2729字正文，既有小说及编辑卡保持原样。

人物、雇主、业务事件及制度均为虚构。真实品牌用于产品背景和架空行业案例，不表示其发生过文中事件。品牌基础信息依据背景知识整理，本次官方网页请求被代理403拒绝，未完成现场核验；具体事实状态与待核入口见第三卷。薪资40万元、职级规则、工具及绩效流程均不能引用为宝洁政策。

阅读顺序：第一卷世界与人物→第二卷术语→第三卷品牌→第四卷组织→第五卷选题与大纲→第六卷技法与质量→第七卷目录与连续性。

维护源为“分卷”目录与作品目录.csv。本文件由校验与汇编.py重建。单独复制案例篇时须保留其随文虚构标识。所有新选题先确定讽刺命题，再选择产品与情节。

---

'''
# 汇编后所有分卷中的“../作品目录.csv”链接改为主文档同目录链接。
master = intro + '\n\n---\n\n'.join(texts)
master = master.replace('(../作品目录.csv)', '(作品目录.csv)')
target = ROOT / '甲虫文学｜快消职场荒诞小说创作圣经.md'
target.write_text(master.rstrip() + '\n', encoding='utf-8')
print(f'术语：{len(terms)}；选题：{len(topics)}；品牌：{len(brands)}，每品牌至少3题。')
print('重点大纲去空白字符数：')
for title, count in lengths:
    print(f'  {title}: {count}')
print(f'十项评分总和全部一致，全部不低于40；完整初稿{len(fiction)}篇，用户定稿与发布记录均为0。')
print('T12／T96、学历、Thomas四个月、Buddy起点、新人汇报线、58字数及既有正文保护校验通过。')
print(f'已汇编：{target.name}（{len(master):,}字符）。')
